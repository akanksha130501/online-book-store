select * from jatin_Products;
